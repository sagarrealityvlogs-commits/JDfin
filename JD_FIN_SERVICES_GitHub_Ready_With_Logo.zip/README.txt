JD FIN SERVICES — GitHub Pages website

FILES
- index.html: complete responsive bilingual English/Marathi website. No build step required.
- logo.jpg: your supplied JD FIN SERVICES logo.

UPLOAD TO GITHUB
1. Open your jd-fin-services repository.
2. Add file -> Upload files.
3. Upload both index.html and logo.jpg (not the ZIP itself).
4. Commit changes.
5. Settings -> Pages -> Deploy from a branch.
6. Branch: main | Folder: /(root) | Save.
7. Wait for GitHub Pages to publish the website.

CONTACT
The enquiry form opens WhatsApp to +91 91755 46576. It does not save enquiries to a database or Google Sheet.
No Aadhaar/PAN/bank documents are collected by this form.

IMPORTANT
- This is a fresh GitHub-ready recreation based on the details available in the conversation. The previous exact website ZIP/logo file was not available in this session.
- Replace the WhatsApp number in index.html if it changes. Search for 919175546576.
- Add your own domain later through Settings -> Pages -> Custom domain.
